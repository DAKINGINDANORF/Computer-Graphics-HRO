# Computer graphics opdracht 3 Tommie Terhoeve 0926280 TI2B
from grid import *

g = Grid(100, 100)
g.rasterline(10, 20, 100, 50)
g.rasterline(1, 1, 100, 3)
g.rasterline(3, 3, 6, 100)
g.rasterline(40, 40, 60, 60)
g.draw()
